This repository contains functions for analysis of in vivo electrophysiology data. It is still in early stages of development, but all functions in the main branch should be functional. 

This goal of this module is to be very flexible, allowing for use with many different file types. To do this, all the functions run using timestamps and values associated to those timestamps. In the future, integration with Neo/NWB would be ideal.
